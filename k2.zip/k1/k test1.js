describe("Calc",function(){
	var a;
	var b;
	beforeEach(function(){
	a=10;
	b=20;
	})
	it("cal",function(){
	expect(addition(a,b)).toBe(a+b);

	});
})
